import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/order_model.dart';
import '../../providers/order_provider.dart';
import '../../widgets/common.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<OrderProvider>();
    final orders = provider.orders;

    Widget body;
    if (provider.loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (provider.error != null) {
      body = Center(child: Text(provider.error!));
    } else if (orders.isEmpty) {
      body = const Center(child: Text('You have not placed any orders yet.'));
    } else {
      body = ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: orders.length,
        // ValueKey keeps each card's state tied to its order, so the card
        // rebuilds correctly when its status changes.
        itemBuilder: (_, i) => _OrderCard(
          key: ValueKey(orders[i].id),
          order: orders[i],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('My Orders')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
          child: body,
        ),
      ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  const _OrderCard({super.key, required this.order});
  final StoreOrder order;

  /// Shared Firestore update + feedback.
  /// Uses a ScaffoldMessenger captured BEFORE the dialog was opened, so the
  /// SnackBar still works after the dialog has been closed.
  Future<void> _updateOrder({
    required ScaffoldMessengerState messenger,
    required Map<String, dynamic> data,
    required String successMessage,
    required Color successColor,
  }) async {
    try {
      await FirebaseFirestore.instance
          .collection('orders')
          .doc(order.id)
          .update(data);

      messenger.hideCurrentSnackBar();
      messenger.showSnackBar(
        SnackBar(
          content: Text(successMessage),
          backgroundColor: successColor,
          duration: const Duration(seconds: 3),
        ),
      );
    } on FirebaseException catch (e) {
      // e.code == 'permission-denied' means your Firestore RULES block this update.
      debugPrint('Order update failed: ${e.code} - ${e.message}');
      messenger.hideCurrentSnackBar();
      messenger.showSnackBar(
        SnackBar(
          content: Text('Update failed (${e.code}). Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    } catch (e) {
      debugPrint('Order update failed: $e');
      messenger.hideCurrentSnackBar();
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Something went wrong. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _showCancelConfirmation(BuildContext context) {
    final messenger = ScaffoldMessenger.of(context);

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Cancel Order'),
        content: const Text('Are you sure you want to cancel this pending order?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('No, Keep Order'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              Navigator.pop(dialogContext);
              _updateOrder(
                messenger: messenger,
                data: {
                  'status': 'Cancelled',
                  'updatedAt': FieldValue.serverTimestamp(),
                },
                successMessage: 'Order has been cancelled.',
                successColor: Colors.grey.shade800,
              );
            },
            child: const Text('Yes, Cancel', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showClaimDialog(BuildContext context) {
    final messenger = ScaffoldMessenger.of(context);
    int selectedRating = 5;
    final feedbackController = TextEditingController();

    showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        // NOTE: the inner context is named `_` on purpose. Before, it shadowed
        // the outer `context`, so `context.mounted` was checking the dialog
        // (already closed) and returned early -> no SnackBar ever appeared.
        builder: (_, setStateSB) => AlertDialog(
          title: const Text('Claim Order & Rate'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Please rate your order and optionally leave feedback.'),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    return IconButton(
                      icon: Icon(
                        index < selectedRating ? Icons.star : Icons.star_border,
                        color: Colors.amber,
                        size: 30,
                      ),
                      onPressed: () => setStateSB(() => selectedRating = index + 1),
                    );
                  }),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: feedbackController,
                  decoration: const InputDecoration(
                    labelText: 'Feedback / Review (optional)',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final review = feedbackController.text.trim();
                Navigator.pop(dialogContext);
                _updateOrder(
                  messenger: messenger,
                  data: {
                    'status': 'Claimed',
                    'rating': selectedRating,
                    'review': review,
                    'claimedAt': FieldValue.serverTimestamp(),
                    'updatedAt': FieldValue.serverTimestamp(),
                  },
                  successMessage: 'Order Claimed! Admin has been notified.',
                  successColor: Colors.green,
                );
              },
              child: const Text('Confirm Claim'),
            ),
          ],
        ),
      ),
    );
  }

  void _showReturnDialog(BuildContext context) {
    final messenger = ScaffoldMessenger.of(context);
    String selectedReason = 'Damaged or defective item';
    final detailsController = TextEditingController();
    final reasons = [
      'Damaged or defective item',
      'Wrong item delivered',
      'Missing parts or accessories',
      'Poor quality / does not match description',
      'Changed mind / size doesn’t fit',
    ];

    showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setStateSB) => AlertDialog(
          title: const Text('Request Refund / Return'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Select a reason for your refund request:'),
                const SizedBox(height: 8),
                ...reasons.map((r) => InkWell(
                  onTap: () => setStateSB(() => selectedReason = r),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4.0),
                    child: Row(
                      children: [
                        Radio<String>(
                          value: r,
                          groupValue: selectedReason,
                          onChanged: (val) =>
                              setStateSB(() => selectedReason = val!),
                        ),
                        Expanded(
                          child: Text(r, style: const TextStyle(fontSize: 13)),
                        ),
                      ],
                    ),
                  ),
                )),
                const SizedBox(height: 8),
                TextField(
                  controller: detailsController,
                  decoration: const InputDecoration(
                    labelText: 'Additional details or reasons (optional)',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () {
                final details = detailsController.text.trim();
                Navigator.pop(dialogContext);
                _updateOrder(
                  messenger: messenger,
                  data: {
                    'status': 'Return Requested',
                    'returnReason': selectedReason,
                    'returnDetails': details,
                    'returnRequestedAt': FieldValue.serverTimestamp(),
                    'updatedAt': FieldValue.serverTimestamp(),
                  },
                  successMessage: 'Refund Request Sent to Admin!',
                  successColor: Colors.orange,
                );
              },
              child: const Text('Submit Request', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ExpansionTile(
        title: Text('Order #${order.shortId}'),
        subtitle: Text('${formatDateTime(order.createdAt)} | ${money(order.total)}'),
        trailing: StatusChip(order.status),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _Timeline(status: order.status),
          const SizedBox(height: 12),
          for (final i in order.items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(child: Text('${i.quantity} x ${i.name}')),
                  Text(money(i.lineTotal)),
                ],
              ),
            ),
          const Divider(),
          Text('Subtotal ${money(order.subtotal)}  |  Tax ${money(order.tax)}  |  '
              'Shipping ${money(order.shippingFee)}'),
          const SizedBox(height: 8),
          Text('Deliver to: ${order.shipping.name}, ${order.shipping.address}'),
          Text('Phone: ${order.shipping.phone}  |  Payment: ${order.shipping.paymentMethod}'),

          // Display rating & feedback if already claimed
          if (order.rating != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('Your Rating: ', style: TextStyle(fontWeight: FontWeight.bold)),
                Row(
                  children: List.generate(
                    order.rating!,
                        (_) => const Icon(Icons.star, color: Colors.amber, size: 16),
                  ),
                ),
              ],
            ),
            if (order.review != null && order.review!.isNotEmpty)
              Text('Feedback: "${order.review}"',
                  style: const TextStyle(fontStyle: FontStyle.italic)),
          ],

          // Display return/refund status info box
          if (order.status == 'Return Requested' || order.status == 'Refunded') ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(8),
              color: order.status == 'Refunded'
                  ? Colors.purple.shade50
                  : Colors.orange.shade50,
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    order.status == 'Refunded'
                        ? 'Refund Status: Approved & Refunded'
                        : 'Refund Status: Pending Admin Review',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: order.status == 'Refunded'
                          ? Colors.purple
                          : Colors.orange.shade800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('Reason: ${order.returnReason ?? "N/A"}'),
                  if (order.returnDetails != null && order.returnDetails!.isNotEmpty)
                    Text('Details: ${order.returnDetails}'),
                ],
              ),
            ),
          ],

          // --- WORKFLOW BUTTONS ---
          if (order.status == 'Pending') ...[
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                onPressed: () => _showCancelConfirmation(context),
                child: const Text('Cancel Order'),
              ),
            ),
          ] else if (order.status == 'Processing') ...[
            const Padding(
              padding: EdgeInsets.only(top: 8.0),
              child: Text(
                'Order is being processed by the store and can no longer be cancelled directly.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
          ] else if (order.status == 'Delivered') ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: () => _showClaimDialog(context),
                    child: const Text('Claim Order'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                    onPressed: () => _showReturnDialog(context),
                    child: const Text('Request Refund'),
                  ),
                ),
              ],
            ),
          ] else if (order.status == 'Claimed') ...[
            const SizedBox(height: 12),
            const Text('Order claimed successfully.',
                style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
          ] else if (order.status == 'Return Requested') ...[
            const SizedBox(height: 12),
            const Text('Your refund request is under review by admin.',
                style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
          ] else if (order.status == 'Refunded') ...[
            const SizedBox(height: 12),
            const Text('This order has been refunded.',
                style: TextStyle(color: Colors.purple, fontWeight: FontWeight.bold)),
          ],
        ],
      ),
    );
  }
}

class _Timeline extends StatelessWidget {
  const _Timeline({required this.status});
  final String status;

  static const _steps = ['Pending', 'Processing', 'Shipped', 'Delivered'];

  @override
  Widget build(BuildContext context) {
    if (status == 'Cancelled' ||
        status == 'Claimed' ||
        status == 'Return Requested' ||
        status == 'Refunded') {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Text('Order Status: $status',
            style: const TextStyle(color: Colors.blueGrey, fontWeight: FontWeight.bold)),
      );
    }
    final current = _steps.indexOf(status);
    final color = Theme.of(context).colorScheme.primary;
    return Row(
      children: [
        for (var i = 0; i < _steps.length; i++)
          Expanded(
            child: Column(
              children: [
                Icon(
                  i <= current ? Icons.check_circle : Icons.radio_button_unchecked,
                  color: i <= current ? color : Colors.grey,
                  size: 22,
                ),
                const SizedBox(height: 4),
                Text(_steps[i],
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: i == current ? FontWeight.bold : FontWeight.normal)),
              ],
            ),
          ),
      ],
    );
  }
}
