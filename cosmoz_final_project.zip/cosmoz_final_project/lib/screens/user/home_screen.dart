import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/product_provider.dart';
import '../../providers/cart_provider.dart';
import '../../providers/auth_provider.dart';
import 'cart_screen.dart';
import 'orders_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _searchQuery = '';
  String _selectedPet = 'All';
  String _selectedCategory = 'All';

  final List<String> _categories = [
    'All',
    'Toys',
    'Leashes & Collars',
    'Beds',
    'Grooming',
    'Feeding',
    'Travel',
    'Other'
  ];

  /// Placeholder shown when a product has no (or a broken) image URL.
  /// Matches the web admin thumbnail: rounded light tile + pet emoji only
  /// (🐶 Dog, 🐱 Cat, 🐾 Both) - no text label.
  Widget _buildPetBadge(String targetPet) {
    final lower = targetPet.toLowerCase();

    String emoji = '🐾'; // Both
    if (lower.contains('dog')) {
      emoji = '🐶';
    } else if (lower.contains('cat')) {
      emoji = '🐱';
    }

    return Container(
      width: double.infinity,
      color: Colors.white,
      alignment: Alignment.center,
      // FittedBox keeps it from overflowing on small phones.
      child: FittedBox(
        fit: BoxFit.scaleDown,
        // Same soft tile as the admin dashboard (#eef3f2).
        child: Container(
          width: 80,
          height: 80,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xFFEEF3F2),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Text(emoji, style: const TextStyle(fontSize: 42)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final productProvider = context.watch<ProductProvider>();
    final cartProvider = context.watch<CartProvider>();
    final authProvider = context.watch<AuthProvider>();

    final products = productProvider.products.where((p) {
      if (_selectedPet != 'All' &&
          p.targetPet != _selectedPet &&
          p.targetPet != 'Both') {
        return false;
      }
      if (_selectedCategory != 'All' && p.category != _selectedCategory) {
        return false;
      }
      if (_searchQuery.isNotEmpty &&
          !p.name.toLowerCase().contains(_searchQuery.toLowerCase())) {
        return false;
      }
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Cosmoz Pet Equipment Store'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person),
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ProfileScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.receipt_long),
            tooltip: 'My Orders',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const OrdersScreen()),
            ),
          ),
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart),
                tooltip: 'Cart',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CartScreen()),
                ),
              ),
              if (cartProvider.items.isNotEmpty)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '${cartProvider.items.length}',
                      style: const TextStyle(fontSize: 10, color: Colors.white),
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sign Out',
            onPressed: () => authProvider.signOut(),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search & Filter header
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Search toys, leashes, beds...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
                isDense: true,
              ),
              onChanged: (val) => setState(() => _searchQuery = val),
            ),
          ),
          // Pet filter chips
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: ['All', 'Dog', 'Cat'].map((pet) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0),
                child: ChoiceChip(
                  label: Text(pet),
                  selected: _selectedPet == pet,
                  onSelected: (_) => setState(() => _selectedPet = pet),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 8),
          // Category filter list
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              children: _categories.map((cat) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4.0),
                  child: ChoiceChip(
                    label: Text(cat),
                    selected: _selectedCategory == cat,
                    onSelected: (_) => setState(() => _selectedCategory = cat),
                  ),
                );
              }).toList(),
            ),
          ),
          const Divider(),
          // Product Grid
          Expanded(
            child: products.isEmpty
                ? const Center(child: Text('No products found.'))
                : GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate:
              const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.72,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(12)),
                          child: product.imageUrl.startsWith('http')
                              ? Image.network(
                            product.imageUrl,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder:
                                (context, error, stackTrace) =>
                                _buildPetBadge(
                                    product.targetPet),
                          )
                              : _buildPetBadge(product.targetPet),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              product.name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              product.category,
                              style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 11),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment:
                              MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  '₱${product.price.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                      color: Colors.teal,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13),
                                ),
                                InkWell(
                                  onTap: product.stock > 0
                                      ? () {
                                    cartProvider.add(product);
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(
                                      SnackBar(
                                        content: Text(
                                            '${product.name} added to cart!'),
                                        duration: const Duration(
                                            milliseconds: 800),
                                      ),
                                    );
                                  }
                                      : null,
                                  child: Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: product.stock > 0
                                          ? Colors.teal
                                          : Colors.grey,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(
                                        Icons.add_shopping_cart,
                                        color: Colors.white,
                                        size: 16),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '${product.stock} in stock',
                              style: TextStyle(
                                  fontSize: 10,
                                  color: product.stock > 0
                                      ? Colors.grey.shade600
                                      : Colors.red),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
