import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/cart_provider.dart';
import '../../providers/product_provider.dart';
import '../../widgets/common.dart';
import 'cart_screen.dart';

/// Looks the product up by id on every build, so price/stock edits made by the
/// admin appear here live (and a deleted product is handled gracefully).
class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key, required this.productId});

  final String productId;

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int _qty = 1;

  @override
  Widget build(BuildContext context) {
    final product = context.watch<ProductProvider>().byId(widget.productId);

    if (product == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('This product is no longer available.')),
      );
    }

    final maxQty = product.stock;
    final qty = maxQty > 0 ? _qty.clamp(1, maxQty).toInt() : 0;

    return Scaffold(
      appBar: AppBar(title: Text(product.name)),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AspectRatio(
                  aspectRatio: 16 / 9,
                  child: ProductImage(product, size: 200),
                ),
              ),
              const SizedBox(height: 16),
              Wrap(spacing: 8, children: [
                Chip(label: Text(product.petLabel)),
                Chip(label: Text(product.category)),
              ]),
              const SizedBox(height: 8),
              Text(product.name, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 4),
              Text(money(product.price),
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                maxQty > 0 ? '$maxQty in stock' : 'Out of stock',
                style: TextStyle(color: maxQty > 0 ? Colors.green[700] : Colors.red),
              ),
              const SizedBox(height: 16),
              Text(product.description.isEmpty
                  ? 'No description provided.'
                  : product.description),
              const SizedBox(height: 24),
              if (maxQty > 0)
                Row(
                  children: [
                    IconButton.outlined(
                      onPressed: qty > 1 ? () => setState(() => _qty = qty - 1) : null,
                      icon: const Icon(Icons.remove),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text('$qty',
                          style: Theme.of(context).textTheme.titleMedium),
                    ),
                    IconButton.outlined(
                      onPressed:
                      qty < maxQty ? () => setState(() => _qty = qty + 1) : null,
                      icon: const Icon(Icons.add),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: FilledButton.icon(
                        icon: const Icon(Icons.add_shopping_cart),
                        label: const Text('Add to cart'),
                        onPressed: () {
                          final error = context
                              .read<CartProvider>()
                              .add(product, quantity: qty);
                          if (error != null) {
                            showSnack(context, error);
                            return;
                          }
                          showSnack(context, '$qty x ${product.name} added to cart');
                        },
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.shopping_cart_outlined),
                label: const Text('View cart'),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const CartScreen()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
