import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../widgets/common.dart';
import 'login_screen.dart';
import 'user/home_screen.dart';

/// Decides what to show from the live auth state - no manual
/// Navigator.pushReplacement is needed after login/logout.
///
///  loading    -> splash
///  signedOut  -> login
///  signedIn   -> catalog (customers) / notice (admins use the web dashboard)
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    switch (auth.status) {
      case AuthStatus.loading:
        return const SplashScreen();
      case AuthStatus.signedOut:
        return const LoginScreen();
      case AuthStatus.signedIn:
        return auth.isAdmin
            ? const AccessDeniedScreen(
            message:
            'Administrator accounts sign in at the web admin dashboard.')
            : const HomeScreen();
    }
  }
}
