import 'package:cloud_firestore/cloud_firestore.dart';

/// A registered account, stored at `users/{uid}`.
///
/// `role` is either `customer` or `admin`. It can only be set to `admin`
/// manually in the Firebase console (see SETUP.md) - Firestore rules stop
/// clients from granting themselves that role.
class AppUser {
  const AppUser({
    required this.uid,
    required this.name,
    required this.email,
    required this.role,
    this.createdAt,
  });

  final String uid;
  final String name;
  final String email;
  final String role;
  final DateTime? createdAt;

  bool get isAdmin => role == 'admin';

  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const <String, dynamic>{};
    return AppUser(
      uid: doc.id,
      name: d['name'] as String? ?? '',
      email: d['email'] as String? ?? '',
      role: d['role'] as String? ?? 'customer',
      createdAt: (d['createdAt'] as Timestamp?)?.toDate(),
    );
  }
}
