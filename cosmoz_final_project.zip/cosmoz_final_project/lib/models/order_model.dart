import 'package:cloud_firestore/cloud_firestore.dart';
import 'product_model.dart';

/// Order lifecycle controlled from the admin dashboard.
const List<String> kOrderStatuses = [
  'Pending',
  'Processing',
  'Shipped',
  'Delivered',
  'Claimed',
  'Return Requested',
  'Refunded',
  'Cancelled',
];

/// Single source of truth for fees, used by the cart UI *and* by checkout.
class Pricing {
  static const double taxRate = 0.05;
  static const double flatShipping = 50.0;

  static double tax(double subtotal) =>
      double.parse((subtotal * taxRate).toStringAsFixed(2));

  static double shipping(double subtotal) => subtotal > 0 ? flatShipping : 0;
}

String shortOrderId(String id) =>
    (id.length > 6 ? id.substring(0, 6) : id).toUpperCase();

/// A line in the shopping cart (client-side only).
class CartItem {
  CartItem({required this.product, this.quantity = 1});

  final Product product;
  int quantity;

  double get lineTotal => product.price * quantity;
}

/// Delivery details collected at checkout.
class ShippingInfo {
  const ShippingInfo({
    required this.name,
    required this.phone,
    required this.address,
    this.paymentMethod = 'Cash on Delivery',
  });

  final String name;
  final String phone;
  final String address;
  final String paymentMethod;
}

/// A line inside a saved order. Name and price are snapshotted.
class OrderItem {
  const OrderItem({
    required this.productId,
    required this.name,
    required this.price,
    required this.quantity,
  });

  final String productId;
  final String name;
  final double price;
  final int quantity;

  double get lineTotal => price * quantity;

  Map<String, dynamic> toMap() => {
    'productId': productId,
    'name': name,
    'price': price,
    'quantity': quantity,
  };

  factory OrderItem.fromMap(Map<String, dynamic> m) => OrderItem(
    productId: m['productId'] as String? ?? '',
    name: m['name'] as String? ?? '',
    price: (m['price'] as num?)?.toDouble() ?? 0,
    quantity: (m['quantity'] as num?)?.toInt() ?? 0,
  );
}

/// A customer order, stored at `orders/{id}`.
class StoreOrder {
  const StoreOrder({
    required this.id,
    required this.userId,
    required this.userEmail,
    required this.items,
    required this.subtotal,
    required this.tax,
    required this.shippingFee,
    required this.total,
    required this.status,
    required this.shipping,
    required this.createdAt,
    this.rating,
    this.review,
    this.returnReason,
    this.returnDetails,
  });

  final String id;
  final String userId;
  final String userEmail;
  final List<OrderItem> items;
  final double subtotal;
  final double tax;
  final double shippingFee;
  final double total;
  final String status;
  final ShippingInfo shipping;
  final DateTime createdAt;
  final int? rating;
  final String? review;
  final String? returnReason;
  final String? returnDetails;

  String get shortId => shortOrderId(id);
  int get itemCount => items.fold<int>(0, (s, i) => s + i.quantity);

  factory StoreOrder.fromDoc(DocumentSnapshot doc) {
    final d = (doc.data() as Map<String, dynamic>?) ?? const <String, dynamic>{};
    final rawItems = d['items'];
    final items = rawItems is List
        ? rawItems
        .whereType()
        .map((m) => OrderItem.fromMap(Map<String, dynamic>.from(m)))
        .toList()
        : <OrderItem>[];
    final created = d['createdAt'];
    final legacy = d['orderDate'];
    final DateTime createdAt = created is Timestamp
        ? created.toDate()
        : (legacy is String ? DateTime.tryParse(legacy) : null) ?? DateTime.now();

    return StoreOrder(
      id: doc.id,
      userId: d['userId'] as String? ?? '',
      userEmail: d['userEmail'] as String? ?? '',
      items: items,
      subtotal: (d['subtotal'] as num?)?.toDouble() ?? 0,
      tax: (d['tax'] as num?)?.toDouble() ?? 0,
      shippingFee: (d['shippingFee'] as num?)?.toDouble() ?? 0,
      total: (d['total'] as num?)?.toDouble() ?? 0,
      status: d['status'] as String? ?? 'Pending',
      shipping: ShippingInfo(
        name: d['shippingName'] as String? ?? '',
        phone: d['shippingPhone'] as String? ?? '',
        address: d['shippingAddress'] as String? ?? '',
        paymentMethod: d['paymentMethod'] as String? ?? 'Cash on Delivery',
      ),
      createdAt: createdAt,
      rating: (d['rating'] as num?)?.toInt(),
      review: d['review'] as String?,
      returnReason: d['returnReason'] as String?,
      returnDetails: d['returnDetails'] as String?,
    );
  }

  Map<String, dynamic> toCreateMap() => {
    'userId': userId,
    'userEmail': userEmail,
    'items': items.map((i) => i.toMap()).toList(),
    'subtotal': subtotal,
    'tax': tax,
    'shippingFee': shippingFee,
    'total': total,
    'status': status,
    'shippingName': shipping.name,
    'shippingPhone': shipping.phone,
    'shippingAddress': shipping.address,
    'paymentMethod': shipping.paymentMethod,
    'createdAt': FieldValue.serverTimestamp(),
    'updatedAt': FieldValue.serverTimestamp(),
  };
}