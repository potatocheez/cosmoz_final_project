import 'package:cloud_firestore/cloud_firestore.dart';

/// The store sells equipment for cats and dogs ONLY.
/// 'Both' = suitable for either species (e.g. a travel water bottle).
const List<String> kPetTypes = ['Dog', 'Cat', 'Both'];

/// Equipment categories used by the catalog filter and the admin form.
const List<String> kCategories = [
  'Toys',
  'Leashes & Collars',
  'Beds',
  'Grooming',
  'Feeding',
  'Travel',
  'Other',
];

/// A catalog item, stored at `products/{id}`.
class Product {
  const Product({
    required this.id,
    required this.name,
    required this.targetPet,
    required this.category,
    required this.price,
    required this.description,
    required this.stock,
    this.imageUrl = '',
  });

  final String id;
  final String name;
  final String targetPet; // 'Dog', 'Cat' or 'Both'
  final String category; // one of kCategories
  final double price;
  final String description;
  final int stock;
  final String imageUrl;

  /// Catalog filter: a 'Dog' filter also shows 'Both' items, and vice versa.
  bool matchesPet(String? filter) =>
      filter == null || targetPet == filter || targetPet == 'Both';

  /// Short label with emoji, used on cards and the detail screen.
  String get petLabel {
    switch (targetPet) {
      case 'Cat':
        return '🐱 Cats';
      case 'Dog':
        return '🐶 Dogs';
      default:
        return '🐱🐶 Cats & Dogs';
    }
  }

  /// Defensive parsing: Firestore numbers may arrive as int OR double, and
  /// documents written by older versions of the app may lack fields.
  factory Product.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const <String, dynamic>{};
    final pet = d['targetPet'];
    final category = d['category'];
    return Product(
      id: doc.id,
      name: d['name'] as String? ?? '',
      targetPet: pet is String && kPetTypes.contains(pet) ? pet : 'Dog',
      category:
      category is String && kCategories.contains(category) ? category : 'Other',
      price: (d['price'] as num?)?.toDouble() ?? 0,
      description: d['description'] as String? ?? '',
      stock: (d['stock'] as num?)?.toInt() ?? 0,
      imageUrl: d['imageUrl'] as String? ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
    'name': name,
    'targetPet': targetPet,
    'category': category,
    'price': price,
    'description': description,
    'stock': stock,
    'imageUrl': imageUrl,
  };
}
