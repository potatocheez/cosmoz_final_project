import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

import '../models/app_user.dart';

/// Thin wrapper over Firebase Authentication + the `users/{uid}` profile doc.
/// No UI state lives here - see AuthProvider.
class AuthService {
  AuthService({FirebaseAuth? auth, FirebaseFirestore? firestore})
      : _auth = auth ?? FirebaseAuth.instance,
        _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  /// Live profile (emits null until the profile document exists).
  Stream<AppUser?> watchProfile(String uid) => _db
      .collection('users')
      .doc(uid)
      .snapshots()
      .map((s) => s.exists ? AppUser.fromDoc(s) : null);

  Future<void> signIn({required String email, required String password}) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = cred.user;
    if (user != null) await _ensureProfile(user);
  }

  Future<void> register({
    required String name,
    required String email,
    required String password,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = cred.user;
    if (user == null) throw StateError('Account created but no user returned.');

    try {
      await user.updateDisplayName(name.trim());
    } catch (e) {
      // Not critical - the name is also stored in the profile document.
      debugPrint('updateDisplayName failed: $e');
    }

    try {
      await _ensureProfile(user, name: name.trim());
    } catch (e) {
      // Don't leave an orphan Auth account without a profile
      // (that is what causes "account already exists" on retry).
      try {
        await user.delete();
      } catch (_) {}
      rethrow;
    }
  }

  Future<void> signOut() => _auth.signOut();

  /// Creates the profile for accounts that don't have one yet. The role is
  /// always 'customer'; Firestore rules reject anything else from a client.
  Future<void> _ensureProfile(User user, {String? name}) async {
    final ref = _db.collection('users').doc(user.uid);

    DocumentSnapshot<Map<String, dynamic>> snap;
    try {
      snap = await ref.get();
    } on FirebaseException catch (e) {
      debugPrint('PROFILE STEP FAILED (read): ${e.code} - ${e.message}');
      throw FirebaseException(
        plugin: 'cloud_firestore',
        code: e.code,
        message: '(read profile) ${e.code}',
      );
    }
    if (snap.exists) return;

    try {
      await ref.set({
        'name': name ?? user.displayName ?? '',
        'email': user.email ?? '',
        'role': 'customer',
        'createdAt': FieldValue.serverTimestamp(),
      });
    } on FirebaseException catch (e) {
      debugPrint('PROFILE STEP FAILED (create): ${e.code} - ${e.message}');
      throw FirebaseException(
        plugin: 'cloud_firestore',
        code: e.code,
        message: '(create profile) ${e.code}',
      );
    }
  }
}

/// Turns Firebase exceptions into messages fit for a SnackBar.
String authErrorMessage(Object error) {
  if (error is FirebaseAuthException) {
    switch (error.code) {
      case 'invalid-email':
        return 'That email address is not valid.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Incorrect email or password.';
      case 'email-already-in-use':
        return 'An account already exists for that email.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'too-many-requests':
        return 'Too many attempts. Please wait a moment and try again.';
      case 'network-request-failed':
        return 'Network error. Check your connection.';
      case 'operation-not-allowed':
        return 'Email/password sign-in is not enabled in the Firebase console.';
      default:
        return error.message ?? 'Authentication failed (${error.code}).';
    }
  }
  if (error is FirebaseException) {
    return 'Server error ${error.message ?? error.code}';
  }
  return 'Something went wrong. Please try again.';
}
