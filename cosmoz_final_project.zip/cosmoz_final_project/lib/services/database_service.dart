import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/order_model.dart';
import '../models/product_model.dart';

/// A business-rule failure that is safe to show to the user
/// (e.g. "Only 2 left").
class StoreException implements Exception {
  StoreException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// All Firestore access lives here. It holds no UI state; providers own the
/// stream subscriptions so each stream is opened exactly once.
class DatabaseService {
  DatabaseService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _products =>
      _db.collection('products');
  CollectionReference<Map<String, dynamic>> get _orders =>
      _db.collection('orders');

  // ---------------------------------------------------------------- products

  Stream<List<Product>> watchProducts() => _products.snapshots().map((s) {
    final list = s.docs.map(Product.fromDoc).toList();
    list.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return list;
  });

  // ------------------------------------------------------------------ orders

  /// Orders of one customer, newest first. Sorted on the device so no
  /// composite Firestore index is required.
  Stream<List<StoreOrder>> watchUserOrders(String uid) =>
      _orders.where('userId', isEqualTo: uid).snapshots().map(_ordersFrom);

  List<StoreOrder> _ordersFrom(QuerySnapshot<Map<String, dynamic>> s) {
    final list = s.docs.map(StoreOrder.fromDoc).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  /// Places an order atomically: verifies stock, decrements it and writes the
  /// order in ONE transaction, so two customers can never buy the last item.
  /// Prices are re-read from Firestore, not trusted from the cart.
  /// Returns the new order id.
  Future<String> placeOrder({
    required String userId,
    required String userEmail,
    required List<CartItem> cart,
    required ShippingInfo shipping,
  }) async {
    if (cart.isEmpty) throw StoreException('Your cart is empty.');
    final orderRef = _orders.doc();

    await _db.runTransaction<void>((tx) async {
      // Firestore requires ALL reads to happen before ANY write.
      final snaps = <DocumentSnapshot<Map<String, dynamic>>>[];
      for (final line in cart) {
        snaps.add(await tx.get(_products.doc(line.product.id)));
      }

      final items = <OrderItem>[];
      for (var i = 0; i < cart.length; i++) {
        final line = cart[i];
        final data = snaps[i].data();
        if (!snaps[i].exists || data == null) {
          throw StoreException('"${line.product.name}" is no longer available.');
        }
        final stock = (data['stock'] as num?)?.toInt() ?? 0;
        if (stock < line.quantity) {
          throw StoreException(stock <= 0
              ? '"${line.product.name}" is out of stock.'
              : 'Only $stock of "${line.product.name}" left in stock.');
        }
        items.add(OrderItem(
          productId: snaps[i].id,
          name: data['name'] as String? ?? line.product.name,
          price: (data['price'] as num?)?.toDouble() ?? line.product.price,
          quantity: line.quantity,
        ));
      }

      final subtotal = items.fold<double>(0, (s, i) => s + i.lineTotal);
      final tax = Pricing.tax(subtotal);
      final fee = Pricing.shipping(subtotal);

      for (final item in items) {
        tx.update(_products.doc(item.productId),
            {'stock': FieldValue.increment(-item.quantity)});
      }
      final order = StoreOrder(
        id: orderRef.id,
        userId: userId,
        userEmail: userEmail,
        items: items,
        subtotal: subtotal,
        tax: tax,
        shippingFee: fee,
        total: subtotal + tax + fee,
        status: 'Pending',
        shipping: shipping,
        createdAt: DateTime.now(), // ignored: server timestamp is written
      );
      tx.set(orderRef, order.toCreateMap());
    });

    return orderRef.id;
  }
}
