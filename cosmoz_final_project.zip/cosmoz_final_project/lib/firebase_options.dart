// File location: lib/firebase_options.dart
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos - '
              'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
              'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
              'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "AIzaSyCJXjaVhJub38cQlwZXNrqiQUykw0DPvQo",
    authDomain: "final-project-cbc33.firebaseapp.com",
    projectId: "final-project-cbc33",
    storageBucket: "final-project-cbc33.firebasestorage.app",
    messagingSenderId: "397102873337",
    appId: "1:397102873337:web:10caa8056ad46182964028",
    measurementId: "G-D72PFGJ4K2",
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: "AIzaSyCJXjaVhJub38cQlwZXNrqiQUykw0DPvQo",
    authDomain: "final-project-cbc33.firebaseapp.com",
    projectId: "final-project-cbc33",
    storageBucket: "final-project-cbc33.firebasestorage.app",
    messagingSenderId: "397102873337",
    // Make sure to update this specific App ID once you register your native Android app in Firebase Console
    appId: "1:397102873337:android:YOUR_ANDROID_APP_ID",
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: "AIzaSyCJXjaVhJub38cQlwZXNrqiQUykw0DPvQo",
    authDomain: "final-project-cbc33.firebaseapp.com",
    projectId: "final-project-cbc33",
    storageBucket: "final-project-cbc33.firebasestorage.app",
    messagingSenderId: "397102873337",
    // Make sure to update this specific App ID once you register your native iOS app in Firebase Console
    appId: "123456789",
    iosBundleId: "com.example.cosmozFinalProject",
  );
}