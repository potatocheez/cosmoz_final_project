import 'package:flutter/foundation.dart';

import '../models/order_model.dart';
import '../models/product_model.dart';

/// The shopping cart. Lives above the Navigator so it survives screen changes,
/// and is emptied automatically when the signed-in user changes.
class CartProvider extends ChangeNotifier {
  final List<CartItem> _items = [];
  String? _uid;

  List<CartItem> get items => List.unmodifiable(_items);
  bool get isEmpty => _items.isEmpty;
  int get count => _items.fold<int>(0, (s, i) => s + i.quantity);
  double get subtotal => _items.fold<double>(0, (s, i) => s + i.lineTotal);
  double get tax => Pricing.tax(subtotal);
  double get shipping => Pricing.shipping(subtotal);
  double get total => subtotal + tax + shipping;

  int quantityOf(String productId) {
    for (final i in _items) {
      if (i.product.id == productId) return i.quantity;
    }
    return 0;
  }

  /// Adds [quantity] units. Returns an error message, or null on success.
  /// (Stock is re-checked atomically at checkout; this is the friendly check.)
  String? add(Product product, {int quantity = 1}) {
    if (product.stock <= 0) return '${product.name} is out of stock.';
    final current = quantityOf(product.id);
    if (current + quantity > product.stock) {
      return 'Only ${product.stock} of ${product.name} in stock.';
    }
    final index = _items.indexWhere((i) => i.product.id == product.id);
    if (index >= 0) {
      _items[index].quantity += quantity;
    } else {
      _items.add(CartItem(product: product, quantity: quantity));
    }
    notifyListeners();
    return null;
  }

  String? increment(CartItem item) {
    if (item.quantity + 1 > item.product.stock) {
      return 'Only ${item.product.stock} in stock.';
    }
    item.quantity++;
    notifyListeners();
    return null;
  }

  void decrement(CartItem item) {
    if (item.quantity > 1) {
      item.quantity--;
    } else {
      _items.remove(item);
    }
    notifyListeners();
  }

  void remove(CartItem item) {
    _items.remove(item);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }

  /// Called from a ProxyProvider while the widget tree is building, so it
  /// must NOT call notifyListeners().
  void bindUser(String? uid) {
    if (_uid == uid) return;
    _uid = uid;
    _items.clear();
  }
}
