import 'dart:async';

import 'package:flutter/foundation.dart';

import '../models/app_user.dart';
import '../models/order_model.dart';
import '../services/database_service.dart';

/// Real-time orders of the signed-in customer (query on userId).
/// Every status change made in the web admin dashboard arrives through the
/// Firestore snapshot stream and is also announced on [statusUpdates]
/// (e.g. "Order #A1B2C3 is now Shipped").
class OrderProvider extends ChangeNotifier {
  OrderProvider(this._db);

  final DatabaseService _db;
  final StreamController<String> _updates = StreamController<String>.broadcast();
  final Map<String, String> _knownStatus = {};

  StreamSubscription<List<StoreOrder>>? _sub;
  AppUser? _user;
  String? _boundKey;

  List<StoreOrder> _orders = const [];
  bool _loading = false;
  String? _error;

  List<StoreOrder> get orders => _orders;
  bool get loading => _loading;
  String? get error => _error;
  Stream<String> get statusUpdates => _updates.stream;

  /// Called by a ProxyProvider whenever the signed-in user changes. Runs
  /// during build, so it never calls notifyListeners() synchronously.
  void bind(AppUser? user) {
    final key = user?.uid;
    if (key == _boundKey) return;
    _boundKey = key;

    _sub?.cancel();
    _sub = null;
    _user = user;
    _orders = const [];
    _error = null;
    _knownStatus.clear();

    if (user == null) {
      _loading = false;
      return;
    }
    _loading = true;
    _sub = _db.watchUserOrders(user.uid).listen(_onOrders, onError: (Object e) {
      _error = 'Could not load orders. $e';
      _loading = false;
      notifyListeners();
    });
  }

  void _onOrders(List<StoreOrder> list) {
    for (final o in list) {
      final previous = _knownStatus[o.id];
      if (previous != null && previous != o.status) {
        _updates.add('Order #${o.shortId} is now ${o.status}');
      }
      _knownStatus[o.id] = o.status;
    }
    _orders = list;
    _loading = false;
    _error = null;
    notifyListeners();
  }

  /// Customer checkout. Throws [StoreException] for stock problems.
  Future<String> placeOrder({
    required List<CartItem> cart,
    required ShippingInfo shipping,
  }) async {
    final user = _user;
    if (user == null) throw StoreException('Please sign in again.');
    return _db.placeOrder(
      userId: user.uid,
      userEmail: user.email,
      cart: cart,
      shipping: shipping,
    );
  }

  @override
  void dispose() {
    _sub?.cancel();
    _updates.close();
    super.dispose();
  }
}
