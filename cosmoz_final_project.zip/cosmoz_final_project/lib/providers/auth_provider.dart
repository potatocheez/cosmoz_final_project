import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

import '../models/app_user.dart';
import '../services/auth_service.dart';

enum AuthStatus { loading, signedOut, signedIn }

/// Session state: who is signed in and what role they have.
/// `signedIn` is only reported once the profile document (with the role) has
/// been loaded, so the UI never flashes the wrong screen.
class AuthProvider extends ChangeNotifier {
  AuthProvider(this._service) {
    _authSub = _service.authStateChanges().listen(_onAuthChanged);
  }

  final AuthService _service;
  StreamSubscription<User?>? _authSub;
  StreamSubscription<AppUser?>? _profileSub;

  AuthStatus _status = AuthStatus.loading;
  AppUser? _profile;
  bool _busy = false;

  /// True while a new account is being created. During this time the profile
  /// document does not exist yet, so we must NOT sign the user out.
  bool _registering = false;

  AuthStatus get status => _status;
  AppUser? get profile => _profile;
  bool get isAdmin => _profile?.isAdmin ?? false;
  bool get busy => _busy;

  void _onAuthChanged(User? user) {
    _profileSub?.cancel();
    _profileSub = null;
    _profile = null;

    if (user == null) {
      _status = AuthStatus.signedOut;
      notifyListeners();
      return;
    }

    _status = AuthStatus.loading;
    notifyListeners();

    _profileSub = _service.watchProfile(user.uid).listen(
          (profile) {
        if (_registering) return; // registration in progress: ignore
        if (profile == null) {
          // If the Firestore profile document does not exist, sign out
          // to prevent the app from freezing indefinitely on the loading screen.
          _service.signOut();
          return;
        }
        _profile = profile;
        _status = AuthStatus.signedIn;
        notifyListeners();
      },
      onError: (Object _) {
        if (_registering) return;
        // e.g. permission denied: don't leave the user on a spinner.
        _service.signOut();
      },
    );
  }

  /// Returns null on success, otherwise a user-friendly error message.
  Future<String?> signIn(String email, String password) =>
      _run(() => _service.signIn(email: email, password: password));

  /// Creates the account + profile, then signs out so the user lands on the
  /// login screen. Returns null on success, otherwise an error message.
  Future<String?> register(String name, String email, String password) async {
    _registering = true;
    final error = await _run(
          () => _service.register(name: name, email: email, password: password),
    );
    // Always sign out afterwards: on success the user goes to the login page,
    // on failure we never leave a half-created session behind.
    await _service.signOut();
    _registering = false;
    return error;
  }

  Future<void> signOut() => _service.signOut();

  Future<String?> _run(Future<void> Function() action) async {
    _busy = true;
    notifyListeners();
    try {
      await action();
      return null;
    } catch (e) {
      return authErrorMessage(e);
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _authSub?.cancel();
    _profileSub?.cancel();
    super.dispose();
  }
}
