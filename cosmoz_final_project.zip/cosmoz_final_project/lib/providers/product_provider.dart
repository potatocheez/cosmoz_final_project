import 'dart:async';

import 'package:flutter/foundation.dart';

import '../models/product_model.dart';
import '../services/database_service.dart';

/// Live product catalog + the filters used by the shopping screen.
/// (Product management lives in the web admin dashboard, not in this app.)
class ProductProvider extends ChangeNotifier {
  ProductProvider(this._db) {
    _sub = _db.watchProducts().listen(
          (list) {
        _products = list;
        _loading = false;
        _error = null;
        notifyListeners();
      },
      onError: (Object e) {
        _error = 'Could not load products. $e';
        _loading = false;
        notifyListeners();
      },
    );
  }

  final DatabaseService _db;
  StreamSubscription<List<Product>>? _sub;

  List<Product> _products = const [];
  bool _loading = true;
  String? _error;

  String? _pet; // null = all pets
  String? _category; // null = all categories
  String _query = '';

  List<Product> get products => _products;
  bool get loading => _loading;
  String? get error => _error;
  String? get petFilter => _pet;
  String? get categoryFilter => _category;

  Product? byId(String id) {
    for (final p in _products) {
      if (p.id == id) return p;
    }
    return null;
  }

  /// Products after applying pet, category and search filters.
  List<Product> get visible {
    final q = _query.trim().toLowerCase();
    return _products.where((p) {
      if (!p.matchesPet(_pet)) return false;
      if (_category != null && p.category != _category) return false;
      if (q.isNotEmpty &&
          !p.name.toLowerCase().contains(q) &&
          !p.description.toLowerCase().contains(q)) {
        return false;
      }
      return true;
    }).toList();
  }

  void setPet(String? pet) {
    _pet = pet;
    notifyListeners();
  }

  void setCategory(String? category) {
    _category = category;
    notifyListeners();
  }

  void setQuery(String query) {
    _query = query;
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
