import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

import 'providers/auth_provider.dart';
import 'providers/cart_provider.dart';
import 'providers/order_provider.dart';
import 'providers/product_provider.dart';
import 'screens/auth_gate.dart';
import 'services/auth_service.dart';
import 'services/database_service.dart';

/// Root widget of the customer mobile app: wires every Provider and the theme.
class CosmosPetApp extends StatelessWidget {
  const CosmosPetApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: _providers(),
      child: MaterialApp(
        title: 'Cosmoz Pet Equipment Store',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
        home: const AuthGate(),
      ),
    );
  }
}

List<SingleChildWidget> _providers() => [
  // Services (plain classes, no UI state).
  Provider<AuthService>(create: (_) => AuthService()),
  Provider<DatabaseService>(create: (_) => DatabaseService()),

  // Session.
  ChangeNotifierProvider<AuthProvider>(
    create: (c) => AuthProvider(c.read<AuthService>()),
  ),

  // Public catalog (readable without signing in; see firestore.rules).
  ChangeNotifierProvider<ProductProvider>(
    create: (c) => ProductProvider(c.read<DatabaseService>()),
  ),

  // The next two follow the signed-in user: they re-bind (re-subscribe
  // or reset) whenever AuthProvider reports a different user.
  ChangeNotifierProxyProvider<AuthProvider, CartProvider>(
    lazy: false,
    create: (_) => CartProvider(),
    update: (_, auth, cart) =>
    (cart ?? CartProvider())..bindUser(auth.profile?.uid),
  ),
  ChangeNotifierProxyProvider<AuthProvider, OrderProvider>(
    lazy: false,
    create: (c) => OrderProvider(c.read<DatabaseService>()),
    update: (c, auth, orders) =>
    (orders ?? OrderProvider(c.read<DatabaseService>()))
      ..bind(auth.profile),
  ),
];
