// Firebase web configuration for the admin dashboard.
// Same project as the Flutter app (see lib/firebase_options.dart -> `web`).
// Web API keys are identifiers, not secrets: access is enforced by
// firestore.rules + Firebase Authentication, never by hiding this key.
// To regenerate: Firebase console > Project settings > Your apps > Web app.
export const firebaseConfig = {
  apiKey: "AIzaSyCJXjaVhJub38cQlwZXNrqiQUykw0DPvQo",
  authDomain: "final-project-cbc33.firebaseapp.com",
  projectId: "final-project-cbc33",
  storageBucket: "final-project-cbc33.firebasestorage.app",
  messagingSenderId: "397102873337",
  appId: "1:397102873337:web:10caa8056ad46182964028",
};