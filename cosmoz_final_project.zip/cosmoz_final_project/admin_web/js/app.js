// =============================================================================
// Cosmoz web admin dashboard - vanilla JavaScript + Firebase JS SDK (CDN).
// =============================================================================
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut,
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getFirestore, collection, doc, getDoc, addDoc, updateDoc, deleteDoc,
  onSnapshot, runTransaction, increment, serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const CATEGORIES = ["Toys", "Leashes & Collars", "Beds", "Grooming", "Feeding", "Travel", "Other"];
const STATUSES = ["Pending", "Processing", "Shipped", "Delivered", "Claimed", "Return Requested", "Refunded", "Cancelled"];
const NEXT_STATUS = { Pending: "Processing", Processing: "Shipped", Shipped: "Delivered" };

// ------------------------------- helpers -------------------------------------
const $ = (id) => document.getElementById(id);

const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const money = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const shortId = (id) => id.slice(0, 6).toUpperCase();
const toDate = (ts) => (ts && typeof ts.toDate === "function" ? ts.toDate() : new Date());
const fmtDate = (d) => d.toLocaleString("en-PH", { dateStyle: "medium", timeStyle: "short" });

function toast(message, isError = false) {
  const el = document.createElement("div");
  el.className = "toast" + (isError ? " err" : "");
  el.textContent = message;
  $("toasts").append(el);
  setTimeout(() => el.remove(), 4500);
}

function friendlyError(e) {
  switch (e && e.code) {
    case "auth/invalid-credential":
    case "auth/wrong-password":
    case "auth/user-not-found": return "Incorrect email or password.";
    case "auth/invalid-email": return "That email address is not valid.";
    case "auth/too-many-requests": return "Too many attempts. Please wait and try again.";
    case "auth/network-request-failed": return "Network error. Check your connection.";
    case "permission-denied": return "Permission denied. Is this account an administrator?";
    default: return (e && e.message) || "Something went wrong.";
  }
}

// ------------------------------- state ---------------------------------------
let orders = [];
let products = [];
let customers = [];
let unsubscribers = [];
const expanded = new Set();
const flashing = new Set();
let knownOrderIds = null;
let loginNotice = "";
let lowStockOnly = false;

// ===================== 1. ADMIN LOGIN GATEWAY ================================
onAuthStateChanged(auth, async (user) => {
  stopListening();
  if (!user) return showLogin(loginNotice);
  loginNotice = "";

  try {
    const snap = await getDoc(doc(db, "users", user.uid));
    if (snap.exists() && snap.data().role === "admin") {
      $("admin-email").textContent = user.email;
      showApp();
      startListening();
    } else {
      loginNotice = "This account is not an administrator.";
      await signOut(auth);
    }
  } catch (e) {
    loginNotice = friendlyError(e);
    await signOut(auth);
  }
});

function showLogin(message) {
  $("app-view").hidden = true;
  $("login-view").hidden = false;
  setLoginError(message);
  $("login-btn").disabled = false;
  $("login-btn").textContent = "Sign in";
}
function showApp() {
  $("login-view").hidden = true;
  $("app-view").hidden = false;
}
function setLoginError(message) {
  $("login-error").textContent = message || "";
  $("login-error").hidden = !message;
}

$("login-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const email = $("login-email").value.trim();
  const password = $("login-password").value;
  if (!email || !password) return setLoginError("Enter your email and password.");

  setLoginError("");
  $("login-btn").disabled = true;
  $("login-btn").textContent = "Signing in...";
  try {
    await signInWithEmailAndPassword(auth, email, password);
    $("login-password").value = "";
  } catch (e) {
    showLogin(friendlyError(e));
  }
});

$("logout-btn").addEventListener("click", () => signOut(auth));

// ===================== 2. REAL-TIME LISTENERS ================================
function startListening() {
  knownOrderIds = null;

  unsubscribers.push(onSnapshot(collection(db, "orders"), (snap) => {
    orders = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    orders.sort((a, b) => toDate(b.createdAt) - toDate(a.createdAt));

    const ids = new Set(orders.map((o) => o.id));
    if (knownOrderIds) {
      orders.filter((o) => !knownOrderIds.has(o.id)).forEach((o) => {
        flashing.add(o.id);
        toast(`New update on order #${shortId(o.id)}`);
        setTimeout(() => flashing.delete(o.id), 3000);
      });
    }
    knownOrderIds = ids;
    renderOrders();
  }, onListenError));

  unsubscribers.push(onSnapshot(collection(db, "products"), (snap) => {
    products = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    products.sort((a, b) => String(a.name).localeCompare(String(b.name)));
    renderProducts();
  }, onListenError));

  unsubscribers.push(onSnapshot(collection(db, "users"), (snap) => {
    customers = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    customers.sort((a, b) => String(a.email).localeCompare(String(b.email)));
    renderCustomers();
  }, onListenError));
}

function stopListening() {
  unsubscribers.forEach((u) => u());
  unsubscribers = [];
  orders = []; products = []; customers = [];
  expanded.clear(); flashing.clear();
}

function onListenError(e) {
  console.error(e);
  toast(friendlyError(e), true);
}

// ===================== 3. TABS ===============================================
$("tabs").addEventListener("click", (ev) => {
  const btn = ev.target.closest(".tab");
  if (!btn) return;
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t === btn));
  ["orders", "products", "customers"].forEach((name) => {
    $("tab-" + name).hidden = name !== btn.dataset.tab;
  });
});

// ===================== 4. ORDERS =============================================
$("order-search").addEventListener("input", renderOrders);
$("order-filter").addEventListener("change", renderOrders);

function renderStats() {
  const count = (s) => orders.filter((o) => o.status === s).length;
  const actionNeeded = orders.filter((o) => o.status === "Cancelled" || o.status === "Return Requested").length;
  const revenue = orders.filter((o) => !["Cancelled", "Refunded"].includes(o.status)).reduce((sum, o) => sum + (o.total || 0), 0);

  const cards = [
    ["Total orders", orders.length],
    ["Pending", count("Pending")],
    ["Returns / Claims", count("Return Requested") + count("Claimed")],
    ["Revenue", money(revenue)],
  ];
  $("stats").innerHTML = cards.map(([label, value]) =>
    `<div class="card stat"><b>${esc(value)}</b><span>${esc(label)}</span></div>`).join("");

  const pending = count("Pending") + count("Return Requested");
  $("badge-pending").textContent = pending;
  $("badge-pending").hidden = pending === 0;

  if ($("badge-alerts")) {
    $("badge-alerts").textContent = actionNeeded;
    $("badge-alerts").hidden = actionNeeded === 0;
  }
}

function renderOrders() {
  renderStats();
  const q = $("order-search").value.trim().toLowerCase();
  const status = $("order-filter").value;

  const rows = orders.filter((o) => {
    if (status && o.status !== status) return false;
    if (!q) return true;
    return [shortId(o.id), o.userEmail, o.shippingName].some((v) => String(v || "").toLowerCase().includes(q));
  });

  $("orders-empty").hidden = rows.length > 0;
  $("orders-body").innerHTML = rows.map(orderRow).join("");
}

function orderRow(o) {
  const items = Array.isArray(o.items) ? o.items : [];
  const qty = items.reduce((s, i) => s + (i.quantity || 0), 0);
  const next = NEXT_STATUS[o.status];

  let actions = "";
  if (next) {
    actions += `<button class="btn primary small" data-action="advance" data-id="${esc(o.id)}">Mark ${esc(next)}</button>`;
  }
  if (o.status === "Pending") {
    actions += `<button class="btn danger small" data-action="cancel" data-id="${esc(o.id)}">Cancel</button>`;
  }
  if (o.status === "Return Requested") {
    actions += `<button class="btn primary small" style="background-color: #d32f2f;" data-action="refund" data-id="${esc(o.id)}">Approve Refund</button>`;
  }
  if (!actions) {
    actions = `<span class="muted small">Final (${esc(o.status)})</span>`;
  }

  let html = `
    <tr class="clickable ${flashing.has(o.id) ? "flash" : ""}" data-toggle="${esc(o.id)}">
      <td><b>#${esc(shortId(o.id))}</b></td>
      <td>${esc(fmtDate(toDate(o.createdAt)))}</td>
      <td>${esc(o.shippingName || "-")}<br><span class="muted small">${esc(o.userEmail)}</span></td>
      <td>${qty} item${qty === 1 ? "" : "s"}</td>
      <td class="num">${money(o.total)}</td>
      <td><span class="badge s-${esc(o.status.replace(/\s+/g, '-'))}">${esc(o.status)}</span></td>
      <td><div class="actions">${actions}</div></td>
    </tr>`;

  if (expanded.has(o.id)) {
    let extraDetails = "";
    if (o.status === "Claimed" && o.rating) {
      const stars = "★".repeat(o.rating) + "☆".repeat(5 - o.rating);
      extraDetails = `<div style="margin-top: 8px; color: #2e7d32;"><h4>Customer Rating & Review</h4><span style="color: #ffa000; font-size: 16px;">${stars}</span><br>"${esc(o.review || 'No written review')}"</div>`;
    }
    if (o.status === "Return Requested" || o.status === "Refunded") {
      extraDetails = `<div style="margin-top: 8px; color: #c62828;"><h4>Return / Refund Request</h4><b>Reason:</b> ${esc(o.returnReason)}<br><b>Details:</b> ${esc(o.returnDetails || 'None')}</div>`;
    }

    html += `
    <tr class="details"><td colspan="7"><div class="details-grid">
      <div><h4>Items</h4><ul>${items.map((i) =>
        `<li>${esc(i.quantity)} × ${esc(i.name)} - ${money((i.price || 0) * (i.quantity || 0))}</li>`).join("")}</ul></div>
      <div><h4>Deliver to</h4>${esc(o.shippingName)}<br>${esc(o.shippingAddress)}<br>${esc(o.shippingPhone)}</div>
      <div><h4>Payment</h4>${esc(o.paymentMethod || "Cash on Delivery")}<br>
        <span class="muted small">Subtotal ${money(o.subtotal)} · Tax ${money(o.tax)} · Shipping ${money(o.shippingFee)}</span>
        ${extraDetails}
      </div>
    </div></td></tr>`;
  }
  return html;
}

$("orders-body").addEventListener("click", async (ev) => {
  const btn = ev.target.closest("button[data-action]");
  if (btn) {
    const order = orders.find((o) => o.id === btn.dataset.id);
    if (!order) return;

    let target = "";
    if (btn.dataset.action === "cancel") target = "Cancelled";
    else if (btn.dataset.action === "refund") target = "Refunded";
    else target = NEXT_STATUS[order.status];

    if (target === "Cancelled" && !confirm(`Cancel order #${shortId(order.id)}? Items will be restocked.`)) return;
    if (target === "Refunded" && !confirm(`Approve refund for order #${shortId(order.id)}? Items will be restocked.`)) return;

    btn.disabled = true;
    try {
      await updateOrderStatus(order.id, target);
      toast(`Order #${shortId(order.id)} updated to ${target}`);
    } catch (e) {
      toast(friendlyError(e), true);
      btn.disabled = false;
    }
    return;
  }
  const row = ev.target.closest("tr[data-toggle]");
  if (row) {
    const id = row.dataset.toggle;
    expanded.has(id) ? expanded.delete(id) : expanded.add(id);
    renderOrders();
  }
});

async function updateOrderStatus(orderId, newStatus) {
  const ref = doc(db, "orders", orderId);
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists()) throw new Error("This order no longer exists.");
    const data = snap.data();
    const current = data.status || "Pending";

    if (current === newStatus) return;
    if (newStatus !== "Cancelled" && newStatus !== "Refunded" && NEXT_STATUS[current] !== newStatus) {
      throw new Error(`Order is already ${current}. Refresh and try again.`);
    }

    const restock = [];
    if (newStatus === "Cancelled" || newStatus === "Refunded") {
      for (const item of data.items || []) {
        if (!item.productId) continue;
        const pRef = doc(db, "products", item.productId);
        if ((await tx.get(pRef)).exists()) restock.push({ pRef, qty: item.quantity || 0 });
      }
    }
    restock.forEach(({ pRef, qty }) => tx.update(pRef, { stock: increment(qty) }));
    tx.update(ref, { status: newStatus, updatedAt: serverTimestamp() });
  });
}

// ===================== 5. PRODUCTS (CRUD & FILTERS) ==========================
$("product-search").addEventListener("input", renderProducts);
$("product-filter").addEventListener("change", renderProducts);
$("product-category-filter").addEventListener("change", renderProducts);
$("p-category").innerHTML = CATEGORIES.map((c) => `<option>${esc(c)}</option>`).join("");

const lowStockAlert = $("low-stock-alert");
const lowStockCountEl = $("low-stock-count");
const filterLowStockBtn = $("filter-low-stock-btn");

filterLowStockBtn?.addEventListener("click", () => {
  lowStockOnly = !lowStockOnly;
  filterLowStockBtn.textContent = lowStockOnly ? "Show all products" : "View low stock";
  renderProducts();
});

function renderProducts() {
  const q = $("product-search").value.trim().toLowerCase();
  const pet = $("product-filter").value;
  const category = $("product-category-filter").value;

  const lowStockProducts = products.filter((p) => (p.stock ?? 0) <= 5);
  if (lowStockProducts.length > 0) {
    lowStockAlert.style.display = "flex";
    lowStockAlert.style.alignItems = "center";
    lowStockCountEl.textContent = lowStockProducts.length;
  } else {
    lowStockAlert.style.display = "none";
    lowStockOnly = false;
  }

  const rows = products.filter((p) => {
    if (pet && p.targetPet !== pet) return false;
    if (category && p.category !== category) return false;
    if (lowStockOnly && (p.stock ?? 0) > 5) return false;
    if (q && !String(p.name).toLowerCase().includes(q)) return false;
    return true;
  });

  $("products-empty").hidden = rows.length > 0;
  $("products-body").innerHTML = rows.map((p) => {
    const isLow = (p.stock ?? 0) <= 5;
    const thumb = p.imageUrl
      ? `<img class="thumb" src="${esc(p.imageUrl)}" alt="" loading="lazy" referrerpolicy="no-referrer"
              onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'thumb',textContent:'🐾'}))">`
      : `<div class="thumb">${p.targetPet === "Cat" ? "🐱" : p.targetPet === "Dog" ? "🐶" : "🐾"}</div>`;
    const stockCls = isLow ? "low" : "";
    return `<tr>
      <td>${thumb}</td>
      <td>
        <b>${esc(p.name)}</b>
        ${isLow ? `<span class="badge s-Cancelled" style="margin-left: 6px;">Low Stock</span>` : ""}
      </td>
      <td><span class="badge pet-${esc(p.targetPet)}">${esc(p.targetPet)}</span></td>
      <td>${esc(p.category)}</td>
      <td class="num">${money(p.price)}</td>
      <td class="num ${stockCls}">${esc(p.stock)}</td>
      <td><div class="actions">
        <button class="btn small" data-edit="${esc(p.id)}">Edit</button>
        <button class="btn danger small" data-delete="${esc(p.id)}">Delete</button>
      </div></td></tr>`;
  }).join("");
}

const dialog = $("product-dialog");

function openProductDialog(p) {
  $("product-dialog-title").textContent = p ? "Edit product" : "Add product";
  $("p-id").value = p ? p.id : "";
  $("p-name").value = p ? p.name : "";
  $("p-pet").value = p ? p.targetPet : "Dog";
  $("p-category").value = p && CATEGORIES.includes(p.category) ? p.category : "Toys";
  $("p-price").value = p ? p.price : "";
  $("p-stock").value = p ? p.stock : "";
  $("p-image").value = p ? p.imageUrl || "" : "";
  $("p-desc").value = p ? p.description || "" : "";
  $("product-error").hidden = true;
  dialog.showModal();
}

$("add-product-btn").addEventListener("click", () => openProductDialog(null));
$("product-cancel").addEventListener("click", () => dialog.close());

$("products-body").addEventListener("click", async (ev) => {
  const edit = ev.target.closest("[data-edit]");
  if (edit) return openProductDialog(products.find((p) => p.id === edit.dataset.edit));

  const del = ev.target.closest("[data-delete]");
  if (del) {
    const p = products.find((x) => x.id === del.dataset.delete);
    if (!p || !confirm(`Delete "${p.name}"? Existing orders keep their own copy of the item.`)) return;
    try {
      await deleteDoc(doc(db, "products", p.id));
      toast(`Deleted "${p.name}"`);
    } catch (e) {
      toast(friendlyError(e), true);
    }
  }
});

$("product-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const showErr = (m) => { $("product-error").textContent = m; $("product-error").hidden = false; };

  const data = {
    name: $("p-name").value.trim(),
    targetPet: $("p-pet").value,
    category: $("p-category").value,
    price: Number($("p-price").value),
    stock: Number($("p-stock").value),
    imageUrl: $("p-image").value.trim(),
    description: $("p-desc").value.trim(),
  };

  if (!data.name) return showErr("Enter a product name.");
  if (!["Dog", "Cat", "Both"].includes(data.targetPet)) return showErr("Pet type must be Dog, Cat or Both.");
  if (!(data.price > 0)) return showErr("Price must be greater than 0.");
  if (!Number.isInteger(data.stock) || data.stock < 0) return showErr("Stock must be a whole number (0 or more).");
  if (data.imageUrl && !/^https?:\/\//i.test(data.imageUrl)) return showErr("Image URL must start with http(s)://");

  $("product-save").disabled = true;
  try {
    const id = $("p-id").value;
    if (id) {
      await updateDoc(doc(db, "products", id), data);
    } else {
      await addDoc(collection(db, "products"), { ...data, createdAt: serverTimestamp() });
    }
    dialog.close();
    toast(id ? "Product updated" : "Product added");
  } catch (e) {
    showErr(friendlyError(e));
  } finally {
    $("product-save").disabled = false;
  }
});

// ===================== 6. CUSTOMERS ==========================================
function renderCustomers() {
  $("customers-empty").hidden = customers.length > 0;
  $("customers-body").innerHTML = customers.map((u) => `
    <tr>
      <td>${esc(u.name || "-")}</td>
      <td>${esc(u.email)}</td>
      <td><span class="badge ${u.role === "admin" ? "s-Shipped" : "pet-Both"}">${esc(u.role || "customer")}</span></td>
      <td>${u.createdAt ? esc(fmtDate(toDate(u.createdAt))) : "-"}</td>
    </tr>`).join("");
}