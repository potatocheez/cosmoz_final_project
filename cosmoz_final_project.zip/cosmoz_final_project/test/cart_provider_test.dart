import 'package:flutter_test/flutter_test.dart';

import 'package:cosmoz_final_project/models/order_model.dart';
import 'package:cosmoz_final_project/models/product_model.dart';
import 'package:cosmoz_final_project/providers/cart_provider.dart';

Product _product({
  String id = 'p1',
  double price = 100,
  int stock = 3,
  String pet = 'Dog',
}) =>
    Product(
      id: id,
      name: 'Rope toy',
      targetPet: pet,
      category: 'Toys',
      price: price,
      description: '',
      stock: stock,
    );

void main() {
  group('CartProvider', () {
    test('merges repeated adds into one line', () {
      final cart = CartProvider();
      final p = _product();
      expect(cart.add(p), isNull);
      expect(cart.add(p), isNull);
      expect(cart.items.length, 1);
      expect(cart.count, 2);
    });

    test('refuses to exceed available stock', () {
      final cart = CartProvider();
      final p = _product(stock: 2);
      expect(cart.add(p, quantity: 2), isNull);
      expect(cart.add(p), isNotNull);
      expect(cart.count, 2);
    });

    test('refuses out-of-stock products', () {
      final cart = CartProvider();
      expect(cart.add(_product(stock: 0)), isNotNull);
      expect(cart.isEmpty, isTrue);
    });

    test('decrement removes the line at quantity 1', () {
      final cart = CartProvider();
      cart.add(_product());
      cart.decrement(cart.items.first);
      expect(cart.isEmpty, isTrue);
    });

    test('totals use 5% tax and flat shipping', () {
      final cart = CartProvider();
      cart.add(_product(price: 200), quantity: 2);
      expect(cart.subtotal, 400);
      expect(cart.tax, 20);
      expect(cart.shipping, Pricing.flatShipping);
      expect(cart.total, 470);
    });

    test('empty cart has no shipping charge', () {
      final cart = CartProvider();
      expect(cart.shipping, 0);
      expect(cart.total, 0);
    });

    test('cart is emptied when a different user signs in', () {
      final cart = CartProvider();
      cart.bindUser('alice');
      cart.add(_product());
      cart.bindUser('alice');
      expect(cart.count, 1);
      cart.bindUser('bob');
      expect(cart.isEmpty, isTrue);
    });
  });

  group('Product.matchesPet', () {
    test('no filter shows everything', () {
      expect(_product(pet: 'Cat').matchesPet(null), isTrue);
    });

    test('Dog filter shows Dog and Both, hides Cat', () {
      expect(_product(pet: 'Dog').matchesPet('Dog'), isTrue);
      expect(_product(pet: 'Both').matchesPet('Dog'), isTrue);
      expect(_product(pet: 'Cat').matchesPet('Dog'), isFalse);
    });

    test('Cat filter shows Cat and Both, hides Dog', () {
      expect(_product(pet: 'Cat').matchesPet('Cat'), isTrue);
      expect(_product(pet: 'Both').matchesPet('Cat'), isTrue);
      expect(_product(pet: 'Dog').matchesPet('Cat'), isFalse);
    });
  });
}
